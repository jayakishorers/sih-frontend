export interface MockProfile {
  id: string;
  name: string;
  age: number;
  occupation: string;
  location: string;
  profileImage: string;
  eyeImage: string;
  lastSeen: string;
  verified: boolean;
}

export const mockProfiles: MockProfile[] = [
  {
    id: '001',
    name: 'Sarah Johnson',
    age: 28,
    occupation: 'Software Engineer',
    location: 'San Francisco, CA',
    profileImage: '/images/check.webp',   // ✅ local face image
    eyeImage: '/images/check.webp',       // ✅ local eye image
    lastSeen: '2024-01-15',
    verified: true,
  },
  {
    id: '002',
    name: 'Michael Chen',
    age: 35,
    occupation: 'Data Scientist',
    location: 'Seattle, WA',
    profileImage: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400',
    eyeImage: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400',
    lastSeen: '2024-01-20',
    verified: true,
  },
  {
    id: '003',
    name: 'Emily Rodriguez',
    age: 24,
    occupation: 'UX Designer',
    location: 'Austin, TX',
    profileImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
    eyeImage: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400',
    lastSeen: '2024-01-18',
    verified: true
  },
  {
    id: '004',
    name: 'David Kim',
    age: 31,
    occupation: 'Product Manager',
    location: 'New York, NY',
    profileImage: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
    eyeImage: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400',
    lastSeen: '2024-01-22',
    verified: true
  },
  {
    id: '005',
    name: 'Jessica Williams',
    age: 29,
    occupation: 'Marketing Director',
    location: 'Los Angeles, CA',
    profileImage: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
    eyeImage: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400',
    lastSeen: '2024-01-19',
    verified: true
  },
  {
    id: '006',
    name: 'Alex Thompson',
    age: 26,
    occupation: 'Frontend Developer',
    location: 'Portland, OR',
    profileImage: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400',
    eyeImage: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400',
    lastSeen: '2024-01-21',
    verified: true
  }
];

export const getRandomProfile = (): MockProfile => {
  const randomIndex = Math.floor(Math.random() * mockProfiles.length);
  return mockProfiles[randomIndex];
};

export const generateConfidenceScore = (): number => {
  return Math.floor(Math.random() * (98 - 75 + 1)) + 75;
};