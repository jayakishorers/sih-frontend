export interface ValidationResult {
  isValid: boolean;
  error?: string;
  message?: string;
}

