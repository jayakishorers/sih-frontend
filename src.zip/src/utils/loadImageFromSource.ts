// utils/loadImageFromSource.ts
export const loadImage = (src: string | File): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    if (typeof src === "string") {
      img.src = src;
    } else {
      img.src = URL.createObjectURL(src);
      img.onload = () => { URL.revokeObjectURL(img.src); resolve(img); };
    }
    img.onload = () => resolve(img);
    img.onerror = reject;
  });
