import { mockProfiles } from "../data/mockData";
import { loadImage, detectFaceWithLandmarks, extractEyeRegion } from "./imageUtils";
import { extractFaceEmbedding } from "./faceUtils";  
/**
 * Embedding structure with face + optional eye descriptors
 */
export interface ProfileEmbedding {
  label: string; // profile.id
  faceDescriptors: Float32Array[];
  leftEye?: Float32Array;
  rightEye?: Float32Array;
}

/**
 * Build embeddings for all mock profiles (face + eyes)
 */
export const buildMockEmbeddings = async (): Promise<ProfileEmbedding[]> => {
  const embeddings: ProfileEmbedding[] = [];

  for (const profile of mockProfiles) {
    try {
      // Load profile image
      const faceImg = await loadImage(profile.profileImage);
      const detection = await detectFaceWithLandmarks(faceImg);

      if (!detection) {
        console.warn(`No face detected for ${profile.name}`);
        continue;
      }

      // Get face descriptor
      const faceDescriptor = await extractFaceEmbedding(faceImg);
if (!faceDescriptor) {
  console.warn(`No embedding generated for ${profile.name}`);
  continue;
}

      // Extract eye landmarks
      const eyes = extractEyeRegion(detection.landmarks);

      // Optionally build eye embeddings from profile.eyeImage if available
      let leftEyeDesc: Float32Array | undefined;
      let rightEyeDesc: Float32Array | undefined;

      if (profile.eyeImage) {
        try {
          const eyeImg = await loadImage(profile.eyeImage);
          const eyeDetection = await detectFaceWithLandmarks(eyeImg);

          if (eyeDetection) {
            const eyeLandmarks = extractEyeRegion(eyeDetection.landmarks);

            // For now, just store average landmark positions as descriptors
            // (can replace with CNN embeddings if needed)
            leftEyeDesc = new Float32Array(
              eyeLandmarks.leftEye.flatMap((p) => [p.x, p.y])
            );
            rightEyeDesc = new Float32Array(
              eyeLandmarks.rightEye.flatMap((p) => [p.x, p.y])
            );
          }
        } catch (eyeErr) {
          console.warn(`Could not extract eye embedding for ${profile.name}`, eyeErr);
        }
      }

      embeddings.push({
        label: profile.id,
        faceDescriptors: [faceDescriptor],
        leftEye: leftEyeDesc,
        rightEye: rightEyeDesc,
      });
    } catch (err) {
      console.warn(`Could not extract embedding for ${profile.name}`, err);
    }
  }

  return embeddings;
};
