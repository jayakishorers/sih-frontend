// utils/embeddingsManager.ts
import { buildMockEmbeddings } from "./mockEmbeddingBuilder";
import { loadFromLocal, saveToLocal } from "./embeddingsStorage";
import { ProfileEmbedding } from "./mockEmbeddingBuilder";

const LOCAL_KEY = "iris_mock_embeddings_v1";

export const loadOrBuildEmbeddings = async (): Promise<ProfileEmbedding[]> => {
  // 1. check localStorage
  const cached = loadFromLocal(LOCAL_KEY);
  if (cached && cached.length > 0) {
    console.log("Loaded embeddings from localStorage");
    return cached;
  }

  // 2. otherwise build (this uses your buildMockEmbeddings that uses face-api models)
  const embs = await buildMockEmbeddings();
  if (embs && embs.length > 0) {
    saveToLocal(LOCAL_KEY, embs);
    console.log("Built embeddings and saved to localStorage");
  } else {
    console.warn("No embeddings built from mockProfiles");
  }
  return embs;
};

// optional helper to clear cache during development
export const clearEmbeddingsCache = () => localStorage.removeItem(LOCAL_KEY);
