// utils/embeddingsStorage.ts
import { ProfileEmbedding } from "./mockEmbeddingBuilder";

/** Convert Float32Arrays -> arrays for JSON storage */
export const serializeEmbeddings = (embs: ProfileEmbedding[]) => {
  return embs.map(e => ({
    label: e.label,
    faceDescriptors: e.faceDescriptors.map(d => Array.from(d)),
    leftEye: e.leftEye ? Array.from(e.leftEye) : null,
    rightEye: e.rightEye ? Array.from(e.rightEye) : null,
  }));
};

export const deserializeEmbeddings = (stored: any): ProfileEmbedding[] => {
  if (!Array.isArray(stored)) return [];
  return stored.map((e: any) => ({
    label: e.label,
    faceDescriptors: (e.faceDescriptors || []).map((a: number[]) => new Float32Array(a)),
    leftEye: e.leftEye ? new Float32Array(e.leftEye) : undefined,
    rightEye: e.rightEye ? new Float32Array(e.rightEye) : undefined,
  }));
};

export const saveToLocal = (key: string, embs: ProfileEmbedding[]) =>
  localStorage.setItem(key, JSON.stringify(serializeEmbeddings(embs)));

export const loadFromLocal = (key: string): ProfileEmbedding[] | null => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return deserializeEmbeddings(JSON.parse(raw));
  } catch {
    return null;
  }
};
